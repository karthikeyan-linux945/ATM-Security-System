import cv2
import numpy as np

def preprocess_image(image, target_size=(224, 224)):
    """
    Preprocess image for ML model:
    - Resize
    - Convert to grayscale
    - Normalize
    """

    # Resize image
    image = cv2.resize(image, target_size)

    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Normalize pixel values
    normalized = gray / 255.0

    # Expand dimensions for model input
    processed_image = np.expand_dims(normalized, axis=-1)

    return processed_image
