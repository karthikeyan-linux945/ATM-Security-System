# ==============================
# ATM SECURITY SYSTEM - CONFIG
# ==============================

# ATM DETAILS
ATM_ID = "ATM_102"
ATM_LOCATION = "Chennai - Main Road"

# CAMERA SETTINGS
CAMERA_INDEX = 0
FRAME_WIDTH = 640
FRAME_HEIGHT = 480

# TIMER SETTINGS
WARNING_TIME_SECONDS = 60   # 1 minute threshold

# ALERT SETTINGS
POLICE_CONTACT = "+91XXXXXXXXXX"   # demo number
ENABLE_MESSAGE_ALERT = True
ENABLE_ALARM = True

# AUDIO SETTINGS
ALARM_SOUND_FILE = "alarm.wav"
VOICE_RATE = 150
VOICE_VOLUME = 1.0

# LOG FILE
LOG_FILE_PATH = "logs/alerts.log"
