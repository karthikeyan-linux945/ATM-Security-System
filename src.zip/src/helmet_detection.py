# SIMPLE LOGIC VERSION (can be replaced by ML model)

def helmet_detected(face_region):
    """
    Dummy logic:
    Returns True if helmet/mask is assumed present
    Replace with ML model later
    """
    return True   # assume helmet detected for demo
