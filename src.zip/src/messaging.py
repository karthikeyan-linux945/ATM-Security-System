def send_alert():
    # Simulated police alert
    print("🚨 ALERT SENT TO POLICE 🚨")
    print("ATM ID: ATM_102")
    print("Reason: Helmet/Mask not removed")
