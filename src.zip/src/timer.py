import time

def start_timer(duration=60):
    start_time = time.time()
    while time.time() - start_time < duration:
        pass
    return True
