import cv2
from camera import get_camera
from face_detection import detect_face
from helmet_detection import helmet_detected
from voice_alert import speak
from alarm import play_alarm
from timer import start_timer
from messaging import send_alert

cap = get_camera()
warning_given = False

while True:
    ret, frame = cap.read()
    if not ret:
        break

    faces = detect_face(frame)

    for (x, y, w, h) in faces:
        face_region = frame[y:y+h, x:x+w]

        if helmet_detected(face_region):
            if not warning_given:
                speak("Please remove helmet or face covering")
                warning_given = True

                # Start 1 minute timer
                start_timer(60)

                # Escalation
                speak("Alert triggered")
                play_alarm()
                send_alert()
                break

        cv2.rectangle(frame, (x,y), (x+w,y+h), (0,255,0), 2)

    cv2.imshow("ATM Security System", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
