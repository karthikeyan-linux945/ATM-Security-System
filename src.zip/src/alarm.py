import pygame
import time

def play_alarm():
    pygame.mixer.init()
    pygame.mixer.music.load("alarm.wav")  # keep alarm.wav in project root
    pygame.mixer.music.play()
    time.sleep(5)
    pygame.mixer.music.stop()
